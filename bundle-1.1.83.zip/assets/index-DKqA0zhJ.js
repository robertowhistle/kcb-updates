const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-B2zXq58W.js","./index-CM8pG_h1.js","./index-CKFTGIg0.css"])))=>i.map(i=>d[i]);
import{bG as e,bH as o}from"./index-CM8pG_h1.js";const i=e("Browser",{web:()=>o(()=>import("./web-B2zXq58W.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(r=>new r.BrowserWeb)});export{i as Browser};
