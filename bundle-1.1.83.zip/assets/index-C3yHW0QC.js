const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CP1NItO2.js","./index-CM8pG_h1.js","./index-CKFTGIg0.css"])))=>i.map(i=>d[i]);
import{bG as p,bH as r}from"./index-CM8pG_h1.js";const o=p("App",{web:()=>r(()=>import("./web-CP1NItO2.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
