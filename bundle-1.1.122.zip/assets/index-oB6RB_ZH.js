const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-5t0MZpzr.js","./index-Cf6NO2lv.js","./index-8s9EZmU-.css"])))=>i.map(i=>d[i]);
import{bO as e,bP as o}from"./index-Cf6NO2lv.js";const i=e("Browser",{web:()=>o(()=>import("./web-5t0MZpzr.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(r=>new r.BrowserWeb)});export{i as Browser};
