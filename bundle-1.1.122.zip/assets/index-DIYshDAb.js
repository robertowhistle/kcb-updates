const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DakTvmE-.js","./index-Cf6NO2lv.js","./index-8s9EZmU-.css"])))=>i.map(i=>d[i]);
import{bO as p,bP as r}from"./index-Cf6NO2lv.js";const o=p("App",{web:()=>r(()=>import("./web-DakTvmE-.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
