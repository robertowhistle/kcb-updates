const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BwzfkqZt.js","./index-KC_cPOhB.js","./index-BCd-JC6D.css"])))=>i.map(i=>d[i]);
import{b5 as p,c6 as r}from"./index-KC_cPOhB.js";const o=p("App",{web:()=>r(()=>import("./web-BwzfkqZt.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
