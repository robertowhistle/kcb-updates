const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-B1PN1xE_.js","./index-KC_cPOhB.js","./index-BCd-JC6D.css"])))=>i.map(i=>d[i]);
import{b5 as e,c6 as o}from"./index-KC_cPOhB.js";const i=e("Browser",{web:()=>o(()=>import("./web-B1PN1xE_.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(r=>new r.BrowserWeb)});export{i as Browser};
